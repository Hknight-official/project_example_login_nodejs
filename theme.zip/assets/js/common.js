function getURLVar(key) {
    var value = [];

    var query = String(document.location).split('?');

    if (query[1]) {
        var part = query[1].split('&');

        for (i = 0; i < part.length; i++) {
            var data = part[i].split('=');

            if (data[0] && data[1]) {
                value[data[0]] = data[1];
            }
        }

        if (value[key]) {
            return value[key];
        } else {
            return '';
        }
    }
}

$(document).ready(function() {
    const handledPis = new Set();
    const imgs = [...document.getElementsByClassName('check_img_errs')];
    imgs.forEach(img => {
        if (handledPis.has(img)) {
            return
        }

        img.addEventListener('error', () => {
            img.src = 'assets/image/error_product.png'
        })
    });

    // Highlight any found errors
    $('.text-danger').each(function() {
        var element = $(this).parent().parent();

        if (element.hasClass('form-group')) {
            element.addClass('has-error');
        }
    });

    // Currency
    $('#form-currency .currency-select').on('click', function(e) {
        e.preventDefault();

        $('#form-currency input[name=\'code\']').attr('value', $(this).attr('name'));

        $('#form-currency').submit();
    });

    // Language
    $('#form-language .language-select').on('click', function(e) {
        e.preventDefault();

        $('#form-language input[name=\'code\']').attr('value', $(this).attr('name'));

        $('#form-language').submit();
    })

    /* Search */
    $('#search input[name=\'search\']').parent().find('button').on('click', function() {
        var url = $('base').attr('href') + 'index.php?route=product/search';

        var value = $('header #search input[name=\'search\']').val();

        if (value) {
            url += '&search=' + encodeURIComponent(value);
        }

        location = url;
    });

    $('#search input[name=\'search\']').on('keydown', function(e) {
        if (e.keyCode == 13) {
            $('header #search input[name=\'search\']').parent().find('button').trigger('click');
        }
    });

    // Menu
    $('#menu .dropdown-menu').each(function() {
        var menu = $('#menu').offset();
        var dropdown = $(this).parent().offset();

        var i = (dropdown.left + $(this).outerWidth()) - (menu.left + $('#menu').outerWidth());

        if (i > 0) {
            $(this).css('margin-left', '-' + (i + 5) + 'px');
        }
    });

// Product List
    $('#list-view').click(function() {
        $(".products-category > .clearfix.visible-lg-block").remove();

        $('#content .product-layout').attr('class', 'product-layout product-list col-xs-12');

        localStorage.setItem('display', 'list');

        $('.btn-group').find('#list-view').addClass('selected');
        $('.btn-group').find('#grid-view').removeClass('selected');
    });

    // Checkout
    $(document).on('keydown', '#collapse-checkout-option input[name=\'email\'], #collapse-checkout-option input[name=\'password\']', function(e) {
        if (e.keyCode == 13) {
            $('#collapse-checkout-option #button-login').trigger('click');
        }
    });

    // tooltips on hover
    $('[data-toggle=\'tooltip\']').tooltip({container: 'body'});

    // Makes tooltips work on ajax generated content
    $(document).ajaxStop(function() {
        $('[data-toggle=\'tooltip\']').tooltip({container: 'body'});
    });
});

var time_out_cart;
// Cart add remove functions
var cart = {
    'buyNow': function(product_id, quantity , el) {
        check_popup_confirm(product_id, quantity, el, 'buyNow')
    },
    'add': function(product_id, quantity, el) {
        check_popup_confirm(product_id, quantity, el, 'add')
    },
    'update': function(key, quantity) {
        $.ajax({
            url: 'index.php?route=checkout/cart/edit',
            type: 'post',
            data: 'key=' + key + '&quantity=' + (typeof(quantity) != 'undefined' ? quantity : 1),
            dataType: 'json',
            beforeSend: function() {
                $('#cart > button').button('loading');
            },
            complete: function() {
                $('#cart > button').button('reset');
            },
            success: function(json) {
                // Need to set timeout otherwise it wont update the total
                setTimeout(function () {
                    $('#cart > button').html('<div class="pull-left flip"><h4></h4></div><span id="cart-total"> ' + json['total'] + '</span> <i class="fa fa-caret-down"></i>');
                }, 100);

                if (getURLVar('route') == 'checkout/cart' || getURLVar('route') == 'checkout/checkout') {
                    location = 'index.php?route=checkout/cart';
                } else {
                    $('#cart > ul').load('index.php?route=common/cart/info ul li');
                }
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
            }
        });
    },
    'remove': function(key) {
        $.ajax({
            url: 'index.php?route=checkout/cart/remove',
            type: 'post',
            data: 'key=' + key,
            dataType: 'json',
            beforeSend: function() {
                $('#cart > button').button('loading');
            },
            complete: function() {
                $('#cart > button').button('reset');
            },
            success: function(json) {
                // Need to set timeout otherwise it wont update the total
                setTimeout(function () {
                    $('#cart > button').html('<div class="pull-left flip"><h4></h4></div><span id="cart-total"> ' + json['total'] + '</span> <i class="fa fa-caret-down"></i>');
                    $('#home-cart .heading span').html(json["total"].split(" ")[0]);
                }, 100);

                if (getURLVar('route') == 'checkout/cart' || getURLVar('route') == 'checkout/checkout') {
                    location = 'index.php?route=checkout/cart';
                } else {
                    $('#cart > ul').load('index.php?route=common/cart/info ul li');
                    $('#home-cart > ul').load('index.php?route=common/cart/info ul li');
                }
                $('#alert-position').empty();
                $('#alert-position').append('<div class="alert alert-success"><i class="fa fa-check-circle"></i> ' + json['success'] + ' <button type="button" class="close" data-dismiss="alert">&times;</button></div>');
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
            }
        });
    }
}

var voucher = {
    'add': function() {

    },
    'remove': function(key) {
        $.ajax({
            url: 'index.php?route=checkout/cart/remove',
            type: 'post',
            data: 'key=' + key,
            dataType: 'json',
            beforeSend: function() {
                $('#cart > button').button('loading');
            },
            complete: function() {
                $('#cart > button').button('reset');
            },
            success: function(json) {
                // Need to set timeout otherwise it wont update the total
                setTimeout(function () {
                    $('#cart > button').html('<div class="pull-left flip"><h4></h4></div><span id="cart-total"> ' + json['total'] + '</span> <i class="fa fa-caret-down"></i>');
                }, 100);

                if (getURLVar('route') == 'checkout/cart' || getURLVar('route') == 'checkout/checkout') {
                    location = 'index.php?route=checkout/cart';
                } else {
                    $('#cart > ul').load('index.php?route=common/cart/info ul li');
                }
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
            }
        });
    }
}

var wishlist = {
    'add': function(product_id,el) {
        $.ajax({
            url: 'index.php?route=account/wishlist/add',
            type: 'post',
            data: 'product_id=' + product_id,
            dataType: 'json',
            success: function(json) {
                $('.alert').remove();

                if (json['redirect']) {
                    location = json['redirect'];
                }

                if (json['success']) {
                    $('#content').parent().before('<div class="alert alert-success"><i class="fa fa-check-circle"></i> ' + json['success'] + ' <button type="button" class="close" data-dismiss="alert">&times;</button></div>');
                    $(el).find('i').addClass('icon-added');
                }

                $('#wishlist-total span').html(json['total']);
                $('#wishlist-total').attr('title', json['total']);
                $('#alert-position').empty();
                $('#alert-position').append('<div class="alert alert-success"><i class="fa fa-check-circle"></i> ' + json['success'] + ' <button type="button" class="close" data-dismiss="alert">&times;</button></div>');

                toastr["success"](json['success']);
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
            }
        });
    },
    'remove': function() {

    }
}

var compare = {
    'add': function(product_id) {
        $.ajax({
            url: 'index.php?route=product/compare/add',
            type: 'post',
            data: 'product_id=' + product_id,
            dataType: 'json',
            success: function(json) {
                $('.alert').remove();

                if (json['success']) {
                    $('#content').parent().before('<div class="alert alert-success"><i class="fa fa-check-circle"></i> ' + json['success'] + ' <button type="button" class="close" data-dismiss="alert">&times;</button></div>');

                    $('#compare-total').html(json['total']);

                    $('html, body').animate({ scrollTop: 0 }, 'slow');
                }
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
            }
        });
    },
    'remove': function() {

    }
}

function check_popup_confirm(product_id, quantity, el, type) {
    $.ajax({
        url: 'index.php?route=checkout/cart/check_popup_confirm',
        type: 'POST',
        dataTyoe: 'json',
        data: {
            product_id: product_id,
        },
        success: function (json) {
            if (json.product_option && json.redirect) {
                location.href = json.redirect
                return false;
            }

            if (json.content_popup_confirm) {
                var html =
                    `<div class="modal" id="popup_confirm_checkout" role="dialog">
                        <div class="modal-dialog modal-md modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close btn-cancel-popup-confirm" data-dismiss="modal" aria-label="Close">
                                      <i class="fa fa-times"></i>
                                    </button>
                                     <h4 class="modal-title"><b>${ json.title_popup_confirm }</b></h4>
                                </div>
                                <div class="modal-body">
                                    <div>${ json.content_popup_confirm }</div>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-info float-right btn-submit-popup-confirm">Đã hiểu</button>
                                </div>
                            </div>
                        </div>
                    </div>`;

                $('#confirm_checkout').append(html);
                $('#popup_confirm_checkout').modal({backdrop: 'static', keyboard: false});

                $('.btn-submit-popup-confirm').click(function () {
                    if (type === 'add') {
                        add_cart(product_id, quantity, el);
                    } else if (type === 'buyNow') {
                        buy_now(product_id, quantity, el);
                    }

                    $('#popup_confirm_checkout').modal('hide');
                    $('#confirm_checkout').html('');
                });

                $('.btn-cancel-popup-confirm').click(function () {
                    $('#popup_confirm_checkout').modal('hide');
                    $('#confirm_checkout').html('');
                });
            } else {
                if (type === 'add') {
                    add_cart(product_id, quantity, el);
                } else if (type === 'buyNow') {
                    buy_now(product_id, quantity, el);
                }
            }
        }
    });
}

function add_cart(product_id, quantity, el) {
    // type = 1 là đánh dấu người dùng chọn thêm từ trang chủ

    $.ajax({
        url: 'index.php?route=checkout/cart/add',
        type: 'post',
        data: 'product_id=' + product_id + '&quantity=' + (typeof(quantity) != 'undefined' ? quantity : 1) + '&type=1',
        dataType: 'json',
        beforeSend: function() {
            $('#cart > button').button('loading');
            $(el).attr('disabled', true);
        },
        complete: function() {
            $('#cart > button').button('reset');
        },
        success: function(json) {
            $(el).attr('disabled', false);
            $('.alert, .text-danger').remove();

            if (json['redirect']) {
                location = json['redirect'];
            }

            if (json['success']) {
                window.fbq && window.fbq('track', 'AddToCart',
                    {
                        content_type: 'product',
                        content_ids: product_id,
                    }
                );

                $('#content').parent().before('<div class="alert alert-success"><i class="fa fa-check-circle"></i> ' + json['success'] + ' <button type="button" class="close" data-dismiss="alert">&times;</button></div>');

                // Need to set timeout otherwise it wont update the total
                setTimeout(function () {
                    $('#cart > button').html('<div class="pull-left flip"><h4></h4></div><span id="cart-total"> ' + json['total'] + '</span> <i class="fa fa-caret-down"></i>');
                    $('#home-cart .heading span').html(json["total"].split(" ")[0]);
                    $('.quantity_mobile').html(json["total"].split(" ")[0]);
                }, 100);

                $('.alert-add-cart').css('display', 'unset');

                clearTimeout(time_out_cart);

                time_out_cart = setTimeout(function () {
                   $('.alert-add-cart').css('display', 'none')
                }, 5000);

                $('#cart > ul').load('index.php?route=common/cart/info ul li');
                $('#home-cart > ul').load('index.php?route=common/cart/info ul li');

                $(el).find('i').addClass('icon-added');
            }
        },
        error: function(xhr, ajaxOptions, thrownError) {
            alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
        }
    });
}

function buy_now(product_id, quantity, el) {
    // type = 1 là đánh dấu người dùng chọn thêm từ trang chủ

    $.ajax({
        url: 'index.php?route=checkout/cart/add',
        type: 'post',
        data: 'product_id=' + product_id + '&quantity=' + (typeof(quantity) != 'undefined' ? quantity : 1) + '&type=1',
        dataType: 'json',
        beforeSend: function() {
            $('#cart > button').button('loading');
            $(el).attr('disabled', true);
        },
        complete: function() {
            $('#cart > button').button('reset');
        },
        success: function(json) {
            window.fbq && window.fbq('track', 'AddToCart', {
                content_type: 'product',
                content_ids: product_id,
            });

            if (check_login == false) {
                open_tab_login(product_id);

                // Need to set timeout otherwise it wont update the total
                setTimeout(function () {
                    $('#cart > button').html('<div class="pull-left flip"><h4></h4></div><span id="cart-total"> ' + json['total'] + '</span> <i class="fa fa-caret-down"></i>');
                    $('#home-cart .heading span').html(json["total"].split(" ")[0]);
                    $('.quantity_mobile').html(json["total"].split(" ")[0]);
                }, 100);

                clearTimeout(time_out_cart);

                time_out_cart = setTimeout(function () {
                   $('.alert-add-cart').css('display', 'none')
                }, 5000);

                $('#cart > ul').load('index.php?route=common/cart/info ul li');
                $('#home-cart > ul').load('index.php?route=common/cart/info ul li');

                return false;
            }

            $(el).attr('disabled', false);
            $('.alert, .text-danger').remove();

            if (json['redirect']) {
                location = json['redirect'];
            }

            if (json['success']) {
                location = 'index.php?route=checkout/checkout';
            }
        },
        error: function(xhr, ajaxOptions, thrownError) {
            alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
        }
    });
}

/* Agree to Terms */
$(document).delegate('.agree', 'click', function(e) {
    e.preventDefault();

    $('#modal-agree').remove();

    var element = this;

    $.ajax({
        url: $(element).attr('href'),
        type: 'get',
        dataType: 'html',
        success: function(data) {
            html  = '<div id="modal-agree" class="modal">';
            html += '  <div class="modal-dialog modal-dialog-centered">';
            html += '    <div class="modal-content">';
            html += '      <div class="modal-header">';
            html += '        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>';
            html += '        <h4 class="modal-title">' + $(element).text() + '</h4>';
            html += '      </div>';
            html += '      <div class="modal-body">' + data + '</div>';
            html += '    </div';
            html += '  </div>';
            html += '</div>';

            $('body').append(html);

            $('#modal-agree').modal('show');
        }
    });
});

// Autocomplete */
(function($) {
    $.fn.autocomplete = function(option) {
        return this.each(function() {
            this.timer = null;
            this.items = new Array();

            $.extend(this, option);

            $(this).attr('autocomplete', 'off');

            // Focus
            $(this).on('focus', function() {
                this.request();
            });

            // Blur
            $(this).on('blur', function() {
                setTimeout(function(object) {
                    object.hide();
                }, 200, this);
            });

            // Keydown
            $(this).on('keydown', function(event) {
                switch(event.keyCode) {
                    case 27: // escape
                        this.hide();
                        break;
                    default:
                        this.request();
                        break;
                }
            });

            // Click
            this.click = function(event) {
                event.preventDefault();

                value = $(event.target).parent().attr('data-value');

                if (value && this.items[value]) {
                    this.select(this.items[value]);
                }
            }

            // Show
            this.show = function() {
                var pos = $(this).position();

                $(this).siblings('ul.dropdown-menu').css({
                    top: pos.top + $(this).outerHeight(),
                    left: pos.left
                });

                $(this).siblings('ul.dropdown-menu').show();
            }

            // Hide
            this.hide = function() {
                $(this).siblings('ul.dropdown-menu').hide();
            }

            // Request
            this.request = function() {
                clearTimeout(this.timer);

                this.timer = setTimeout(function(object) {
                    object.source($(object).val(), $.proxy(object.response, object));
                }, 200, this);
            }

            // Response
            this.response = function(json) {
                html = '';

                if (json.length) {
                    for (i = 0; i < json.length; i++) {
                        this.items[json[i]['value']] = json[i];
                    }

                    for (i = 0; i < json.length; i++) {
                        if (!json[i]['category']) {
                            html += '<li data-value="' + json[i]['value'] + '"><a href="#">' + json[i]['label'] + '</a></li>';
                        }
                    }

                    // Get all the ones with a categories
                    var category = new Array();

                    for (i = 0; i < json.length; i++) {
                        if (json[i]['category']) {
                            if (!category[json[i]['category']]) {
                                category[json[i]['category']] = new Array();
                                category[json[i]['category']]['name'] = json[i]['category'];
                                category[json[i]['category']]['item'] = new Array();
                            }

                            category[json[i]['category']]['item'].push(json[i]);
                        }
                    }

                    for (i in category) {
                        html += '<li class="dropdown-header">' + category[i]['name'] + '</li>';

                        for (j = 0; j < category[i]['item'].length; j++) {
                            html += '<li data-value="' + category[i]['item'][j]['value'] + '"><a href="#">&nbsp;&nbsp;&nbsp;' + category[i]['item'][j]['label'] + '</a></li>';
                        }
                    }
                }

                if (html) {
                    this.show();
                } else {
                    this.hide();
                }

                $(this).siblings('ul.dropdown-menu').html(html);
            }

            $(this).after('<ul class="dropdown-menu"></ul>');
            $(this).siblings('ul.dropdown-menu').delegate('a', 'click', $.proxy(this.click, this));

        });
    }
})(window.jQuery);

function loadMore(page,category,el,limit,search,filter_price_from,filter_price_to,filter_tag,path,sort,order){
    $.ajax({
        method:'get',
        url:'index.php?route=common/home/loadMore',
        data:{
            category:category,
            page:page,
            limit:limit,
            search:search,
            filter_price_from:filter_price_from,
            filter_price_to:filter_price_to,
            tag:filter_tag,
            path:path,
            sort:sort,
            order:order,
        },
        success:function (data) {
            $(el).parent().find('.list-container .row').append(data);
            if(data.trim() == '') {
                $('.list-container .row').html(`<div style='font-family: \"Roboto-Condensed-Bold\"' " +
                    "onclick='location.href=\"index.php?route=product/product/steam&search=<?php echo str_replace("'","\'" , $search)?>\"'> Xem thêm game từ steam </div>`);
            }
        }
    });
}

function loadMoreMaxPrice(page,el,price){
    $.ajax({
        method:'get',
        url:'index.php?route=common/home/loadMore',
        data:{
            category:13,
            page:page,
            filter_price_to:price
        },
        success:function (data) {
            $(el).parent('.list-container').find('#max-price').append(data);
        }
    });
}

function filterMaxPrice(el,price){
    $('#max-price').empty();
    price_filter_page = 0;
    $(el).closest('.list-container').find('.view-more').remove();
    $.ajax({
        method:'get',
        url:'index.php?route=common/home/loadMore',
        data:{
            category:13,
            page:0,
            filter_price_to:price
        },
        success:function (data) {
            $(el).closest('.list-container').find('#max-price').append(data);
            $(el).closest('.list-container').append('<div class="view-more btn-aqua" onclick="loadMoreMaxPrice(++price_filter_page,this,'+price+')">Tải thêm sản phẩm</div>')
        }
    });
}

function loadGameDescription(pid,el) {
    $(el).closest('.container').find('.item-detail').load('index.php?route=common/home/getGameDescription&pid='+pid+' div div');
    $(el).parent().find('.active').removeClass('active');
    $(el).addClass('active');
}

function add_hover() {
    $("#home-cart").hover(
        function () {
            $("#dropdown-detail-cart").css("display", "block");
            $(".alert-add-cart").css("display", "none");
            $("body").append("<style>#home-cart:after{display: block;}</style>");
        },
        function () {
            $("#dropdown-detail-cart").css("display", "none");
            $("body").append("<style>#home-cart:after{display: none;}</style>");
        }
    );

    $(".home-mini-profile").hover(
        function () {
            $(".drop-mini-profile").css("display", "block");
        },
        function () {
            $(".drop-mini-profile").css("display", "none");
        }
    );

    $("#mini-login").hover(
        function () {
            $(".drop-mini-login").css("display", "block");
        },
        function () {
            $(".drop-mini-login").css("display", "none");
        }
    );
}

function remove_hover() {
    $("#home-cart").hover(
        function () {
            $("#dropdown-detail-cart").css("display", "none");
            $(".alert-add-cart").css("display", "none");
            $("body").append("<style>#home-cart:after{display: none;}</style>");
        }
    );

    $(".home-mini-profile").hover(
        function () {
            $(".drop-mini-profile").css("display", "none");
        },
    );

    $("#mini-login").hover(
        function () {
            $(".drop-mini-login").css("display", "none");
        },
    );
}

// Detect mobile devices
window.mobileCheck = function() {
    let check = false;
    (function(a){if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4))) check = true;})(navigator.userAgent||navigator.vendor||window.opera);
    return check;
};
