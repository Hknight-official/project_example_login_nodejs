// Chức năng hiển thị thông báo đẩy góc trái màn hình
const actions = [];
let index = -1;
let lastCrawlTimestamp = 0;
let crawlInterval = 25000;
let count = 0;
let interval;

const displayNextAction = () => {
  const ignoreByDefault = index >= actions.length - 1;

  if (
    index >= actions.length - 2 &&
    Date.now() - lastCrawlTimestamp > crawlInterval
  ) {
    lastCrawlTimestamp = Date.now();

    if (document.visibilityState === "visible") {
      $.ajax({
        url: "index.php?route=account/account/get_notification_customer_action",
        dataType: "json",
        type: "get",
        success: (data) => {
          crawlInterval = Math.min(
            Math.max(data.craw_interval || 0, 10000),
            60000
          );

          data.actions.forEach((action) => actions.push(action));

          if (data.actions.length > 0 && ignoreByDefault) {
            displayNextAction();
          }
        },
      });

      count++;

      if (count > 10 && interval) {
        clearInterval(interval);
      }
    }
  }

  if (ignoreByDefault) {
    return;
  }

  index++;

  const { username, product_name, price, image, description, link, product_id } = actions[
    index
  ];

  $(".notification_footer").addClass("visible");

  // Thời gian hiển thị từng thông báo
  setTimeout(
    () => $(".notification_footer").removeClass("visible"),
    time_show_notification
  );

  $(".nt-content").html(
    '<a class="notification_header" data-product-id="' + product_id + '" href="' +
      link +
      '" target="_blank">\n' +
      '  <img src="' +
      image +
      '" alt="' +
      image +
      '">\n' +
      '  <div class="nt-price"> ' +
      price +
      '<img src="assets/icon/dcoin.png" class="dcoin-notification"></span></div>\n' +
      "</a>\n" +
      '<div class="nt-text"><span class="nt-name"> ' +
      username.replace(/[<>'"()]/g, "") +
      ' </span> <span class="nt-action">' +
      description +
      "</span> </div>"
  );
};

// Thời gian chuyển tiếp thông báo
interval = setInterval(displayNextAction, time_next_notification);
displayNextAction();

$(".nt-close").on("click", function () {
  $(".notification_footer").removeClass("visible");

  // Ghi customer_action
  let product_id = $('.notification_header').data('product-id');
  addCustomerAction(product_id, 1);

  clearInterval(interval);

  $.ajax({
      method: 'POST',
      url: 'index.php?route=account/account/close_notify_push',
      dataType: "json",
      data: {
          disable_notify : 1
      },
      success: function (result) {

      }
  })

});

 // Click vào sản phẩm thông báo
$(".nt-content").on("click", function () {
  let product_id = $('.notification_header').data('product-id');
  addCustomerAction(product_id);
});

// Hàm ghi event customer_action
function addCustomerAction(product_id, type = 0) {
  $.ajax({
    method: "POST",
    url: "index.php?route=api/customer_action",
    dataType: "json",
    data: {
      product_id: product_id,
      type      : type
    },
    success: function (result) {}
  });
}

