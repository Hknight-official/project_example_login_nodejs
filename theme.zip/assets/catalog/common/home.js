function hide_banner() {
  $(window).width() < 1420
    ? $(".banner-home-sidebar").hide()
    : $(".banner-home-sidebar").show();
}

$(window).resize(function () {
  hide_banner();
});

$(document).ready(function () {
  hide_banner();
});
