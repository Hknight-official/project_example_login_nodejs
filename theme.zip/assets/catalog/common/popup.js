﻿$(document).ready(function () {
    $.ajax({
        url: 'index.php?route=common/footer/show_popup',
        type: 'get',
        dataType: 'json',
        success: function (json) {
            var path_name = window.location.href;

            $.each(json.list, function (index, value) {
                var html = '';

                // Nếu setting tắt hiển thị trên desktop
                if (value.show_on_desktop == 0 && ($(window).width() > 800 || $(window).width() > 800)) {
                    return;
                }

                 // Nếu setting tắt hiển thị trên mobile
                if (value.show_on_mobile == 0 && ($(window).width() < 800 || $(window).width() < 800)) {
                    return;
                }

                // Nếu url đang hiển thị trong list url bị loại trừ thì ko hiển thị popup
                if (value.method_type == 2 && value.excluded_urls.includes(path_name) === true) {
                    return;
                }

                // Nếu url đang hiển thị không phải trang home thì ko hiển thị popup
                if (value.method_type == 1 && path_name !== link_home) {
                    return;
                }

                // Nếu url đang hiển thị không nằm trong list url thì ko hiển thị popup
                if (value.method_type == 3 && value.show_urls.includes(path_name) === false) {
                    return;
                }

                 // Nếu khách đang đăng nhập cùng session thì ko hiện popup
                if (json.popupv2_repeats && value.repeats == 2 && json.popupv2_repeats.includes(value.popup_id) === true) {
                    return;
                }

                if (value.content_type == 2 || value.content_type == 3) {
                    // Nếu popup là video hoặc ảnh thì hiện popup không có viền

                    html +=
                    `<div class="modal modal-popups" id="modal-popup${value.popup_id}" role="dialog">
                        <div class="modal-dialog">
                           <div class="modal-content" style="background: transparent;box-shadow: none;border: none;">
                               <div class="modal-body popup${value.popup_id}" style="padding: 0;">
                                   <button type="button" class="close btn-close-popup" data-dismiss="modal" style="width: 40px !important;">
                                   <i class="far fa-times" style="font-size: 25px;align-items: center;display: flex;justify-content: center;"></i>
                                   </button>
                               </div>
                           </div>
                       </div>
                   </div>`;
                } else {
                    // Nếu popup là video hoặc ảnh thì hiện popup có viền trắng

                    html +=
                    `<div class="modal modal-popups" id="modal-popup${value.popup_id}" role="dialog">
                        <div class="modal-dialog">
                           <div class="modal-content">
                           <div class="modal-header" style="border-bottom: unset;padding-bottom: 0;">
                            <button type="button" class="close" data-dismiss="modal"><i class="far fa-times" style="font-size: 25px"></i></button>
                           </div>
                           <div class="modal-body popup${value.popup_id}"></div>
                           <div class="modal-footer"></div>
                           </div>
                       </div>
                   </div>`;
                }

                var attr = '';

                // Xử lý nếu có link và mở tab mới

                if (value.content_type == 1 && value.content_html) {
                    if (value.link_redirect && value.new_tab == 1) {
                        attr += '<a href="' + value.link_redirect + '" target="_blank"> '+ value.content_html + '</a>';
                    } else if (value.link_redirect && value.new_tab == 0) {
                        attr += '<a href="' + value.link_redirect + '" > '+ value.content_html + '</a>';
                    } else {
                        attr += value.content_html;
                    }
                }

                // Xử lý nếu poup là video youtube

                if (value.content_type == 2 && value.content_link) {
                    attr +=
                        '<iframe class="video_youtube'+ value.popup_id +'" width="560" height="315" src="'+ value.content_link +'" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
                }

                 // Xử lý nếu poup là ảnh

                if (value.content_type == 3 && value.content_image) {
                    if (value.link_redirect && value.new_tab == 1) {
                        attr += '<a href="' + value.link_redirect + '" target="_blank"><img src="' + value.content_image + '" /></a>';
                    } else if (value.link_redirect && value.new_tab == 0) {
                        attr += '<a href="' + value.link_redirect + '" ><img src="' + value.content_image + '" /></a>';
                    } else {
                        attr += '<img src="' + value.content_image + '" />';
                    }
                }

                // Nếu có set thời gian delay thì popup sẽ bật lên sau xxx giây.

                if (value.delay) {
                    setTimeout(function () {
                        $('#show_popup').append(html);
                        $('.popup' + value.popup_id).append(attr);
                        $('#modal-popup' + value.popup_id).modal({backdrop: 'static', keyboard: false});

                        set_width_defautl()
                    }, value.delay)
                } else {
                    $('#show_popup').append(html);
                    $('.popup' + value.popup_id).append(attr);
                    $('#modal-popup' + value.popup_id).modal({backdrop: 'static', keyboard: false});
                }

                // Xử lý dừng video khi đóng popup

                $('.close').click(function () {
                   $('.video_youtube' + value.popup_id).remove();
                });

                // Nếu prevent_closing == 1 thì cho khách tắt popup khi click ra ngoài và ngược lại.

                if (value.prevent_closing == 1) {
                    $('#modal-popup' + value.popup_id).find('.close').css('display', 'none');

                    $('body').click(function () {
                        $('#modal-popup' + value.popup_id).modal('hide');
                        $('.video_youtube' + value.popup_id).remove();
                    });
                }

                // Tắt popup sau xx giây

                if (value.close_after) {
                    setTimeout(function () {
                        $('#modal-popup' + value.popup_id).modal('hide');
                        $('.video_youtube' + value.popup_id).remove();
                    }, value.close_after);
                }

                // Xử lý kích thước của popup giao diện desktop

                var width_screen_desktop  = $(window).width() * 50/ 100;    // Lấy chiều rộng màn hình
                var height_screen_desktop = $(window).height() * 50/ 100;  // Lấy chiều cao màn hình

                // Lấy chiều rộng của ảnh
                if (value.content_type == 1 || value.width_desktop <= 0) {
                    var width_desktop = $(window).width() * 60 / 100;
                } else {
                    var width_desktop = parseInt(value.width_desktop);
                }

                 // Lấy chiều cao của ảnh
                if (value.content_type == 1 || value.height_desktop <= 0) {
                    var height_desktop = width_desktop * 9 / 17;
                } else {
                    var height_desktop = parseInt(value.height_desktop);
                }

                if (width_desktop > width_screen_desktop || height_desktop > height_screen_desktop) {
                    if (width_desktop / height_desktop > 1) {
                        height_desktop = width_screen_desktop * (height_desktop / width_desktop);
                        width_desktop  = width_screen_desktop;
                    } else if (height_desktop / width_desktop > 1) {
                        width_desktop = height_screen_desktop * (width_desktop / height_desktop);
                        height_desktop = height_screen_desktop;
                    } else {
                        if (value.width_desktop_setting == 0 && value.height_desktop_setting == 0) {
                            width_desktop = Math.min(width_screen_desktop, height_screen_desktop);
                            height_desktop = Math.min(width_screen_desktop, height_screen_desktop);
                        }
                    }
                }

                var width_screen_mb  = $(window).width() * 60/ 100;     // Lấy chiều rộng màn hình
                var height_screen_mb = $(window).height() * 60/ 100;    // Lấy chiều cao màn hình

                // Lấy chiều rộng của ảnh

                if (value.content_type == 1 || value.width_mobile <= 0) {
                    var width_mobile = $(window).width() * 80 / 100;
                } else {
                    var width_mobile = parseInt(value.width_mobile);
                }

                // Lấy chiều cao của ảnh
                if (value.content_type == 1 || value.height_mobile <= 0) {
                    if ($(window).height() < 400) {
                        var height_mobile = width_mobile * 3 / 9;
                    } else {
                        var height_mobile = width_mobile * 3 / 4;
                    }
                } else {
                    var height_mobile = parseInt(value.height_mobile);
                }

                // Xử lý kích thước của popup giao diện mobile

                if (width_mobile > width_screen_mb || height_mobile > height_screen_mb) {
                    if (width_mobile / height_mobile > 1) {
                        height_mobile = width_screen_mb * (height_mobile / width_mobile);
                        width_mobile  = width_screen_mb;
                    } else if (height_mobile / width_mobile > 1) {
                        width_mobile = height_screen_mb * (width_mobile / height_mobile);
                        height_mobile = height_screen_mb;
                    } else {
                        if (value.width_mobile_setting == 0 && value.height_mobile_setting == 0) {
                            width_mobile = Math.min(width_screen_mb, height_screen_mb);
                            height_mobile = Math.min(width_screen_mb, height_screen_mb);
                        }
                    }
                }

                // Set lý kích thước của các phần tử giao diện desktop

                set_width_defautl();

                function set_width_defautl() {
                    if ($(window).width() >= 800 || $(window).height() >= 800) {
                        $('#show_popup #modal-popup' + value.popup_id).css({ "max-width": (width_desktop + 30)  + "px", "max-height": (height_desktop + 30) , "width" : (width_desktop + 30)  + "px","height" : (height_desktop + 30) + "px" });
                        $('#show_popup #modal-popup' + value.popup_id + ' .modal-content').css({"max-width": width_desktop  + "px", "max-height": height_desktop, "width" : width_desktop + "px","height" : height_desktop + "px"});
                        $('#show_popup #modal-popup' + value.popup_id + ' .modal-body').css({"max-width":width_desktop  + "px", "max-height": height_desktop, "width" : width_desktop + "px","height" : height_desktop + "px" });
                    }

                    // Set lý kích thước của các phần tử giao diện mobile

                    if ($(window).width() < 800 || $(window).height() < 800) {
                       $('#show_popup #modal-popup' + value.popup_id).css({ "max-width": (width_mobile + 30)  + "px", "max-height": (height_mobile + 30) , "width" : (width_mobile + 30)  + "px","height" : (height_mobile + 30) + "px" });
                        $('#show_popup #modal-popup' + value.popup_id + ' .modal-content').css({"max-width": width_mobile  + "px", "max-height": height_mobile, "width" : width_mobile + "px","height" : height_mobile + "px"});
                        $('#show_popup #modal-popup' + value.popup_id + ' .modal-body').css({"max-width":width_mobile  + "px", "max-height": height_mobile, "width" : width_mobile + "px","height" : height_mobile + "px" });
                    }

                    if (value.content_type == 1) {
                        $('#show_popup #modal-popup' + value.popup_id + ' .modal-content').css({"max-height": "unset", "height" : "unset"});
                    }
                }

                // Xử lý hiển thị popup trong 1 session

                if (value.repeats == 2) {
                    $.ajax({
                        url: 'index.php?route=common/footer/update_repeats',
                        type: 'post',
                        dataType: 'json',
                        data: {
                            popup_id : value.popup_id
                        },
                    })
                }

                // Update số lần popup được hiển thị ra

                $.ajax({
                    url: 'index.php?route=common/footer/update_times_show_popup',
                    type: 'post',
                    dataType: 'json',
                    data: {
                        popup_id : value.popup_id
                    },
                })
            });
        }
    });
});

