var timeout_handle = null;

var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (x.length > 0) {
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
    }
    myIndex++;
    if (myIndex > x.length) {
      myIndex = 1;
    }
    x[myIndex - 1].style.display = "block";

    timeout_handle = setTimeout(carousel, time_run_link); // Change image every 2 seconds

    $(".w3-content .mySlides").removeClass("animate-down");
    $(".w3-content .mySlides").addClass("animate-up");
  }
}

// Khi click nút chuyển slide trái thì thêm hiệu ứng chạy text từ phải sang trái
$(".left").click(function (e) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (x.length > 0) {
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
    }
    myIndex--;
    if (myIndex < 0) {
      myIndex = x.length - 1;
    }
    x[myIndex].style.display = "block";

    $(".w3-content .mySlides").removeClass("animate-up");
    $(".w3-content .mySlides").addClass("animate-down");

    clearTimeout(timeout_handle);
    timeout_handle = setTimeout(carousel, time_run_link);
  }
});

// Khi click nút chuyển slide trái thì thêm hiệu ứng chạy text từ phải trái sang phải
$(".right").click(function (e) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (x.length > 0) {
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
    }
    myIndex++;
    if (myIndex > x.length) {
      myIndex = 1;
    }
    x[myIndex - 1].style.display = "block";

    $(".w3-content .mySlides").removeClass("animate-down");
    $(".w3-content .mySlides").addClass("animate-up");

    clearTimeout(timeout_handle);
    timeout_handle = setTimeout(carousel, time_run_link);
  }
});

// Check rules facebook
$(".login-fplus").click(function () {
  $.ajax({
    url: "index.php?route=account/login/check_rules_facebook",
    type: "POST",
    success: function (json) {
      if (json["havent_rules"] == 1) {
        $("#modal-accept-facebook").modal("show");
      }

      if (json.href) {
        window.location.href = json.href;
      }
    },
  });
});

// Submit rules facebook
$("#checked_rules_facebook").on("click", function () {
  var check_rules = 1;
  $.ajax({
    url: "index.php?route=account/login/check_rules_facebook",
    type: "POST",
    data: {
      check_rules: check_rules,
    },
    success: function (json) {
      if (json.href) {
        window.location.href = json.href;
      }
    },
  });
});

// Check rules google

$(".login-gplus").click(function () {
  $.ajax({
    url: "index.php?route=extension/module/check_rules_login_google/index",
    type: "POST",
    success: function (json) {
      if (json["havent_rules"] == 1) {
        $("#modal-accept-rules").modal("show");
      }

      if (json.href) {
        window.location.href = json.href;
      }
    },
  });
});

// Submit rules google

$("#checked_rules").on("click", function () {
  var check_rules = 1;
  $.ajax({
    url: "index.php?route=extension/module/check_rules_login_google/index",
    type: "POST",
    data: {
      check_rules: check_rules,
    },
    success: function (json) {
      if (json.href) {
        window.location.href = json.href;
      }
    },
  });
});

// Submit close modal rules

$(".btn-close-modal").on("click", function () {
  $(".modal-rules").modal("hide");
});

$(document).ready(function () {
  var widht_complete = $('.search-control').width() - $('.search-btn').width();

  $('body').click(function (event) {
    $('#search_popular').html('');
  });

  $('#filter_name').click(function (event) {
    event.stopPropagation();
    show_search_popular();
  });

  $('#filter_name').keyup(function () {
    show_search_popular();
  });

  function show_search_popular() {
    if ($("#filter_name").val() != '') {
      $('#search_popular').html('');
    } else {
      $.ajax({
        url: 'index.php?route=common/header/get_product_popular',
        type: 'get',
        dataType: 'json',
        success: function (json) {
          var html =
            `<div class="dropdown-menu" style="margin-bottom: 20px;position: absolute; display: block; width: ${widht_complete}px">
              <div class="title_popular"><i class="fad fa-fire-alt font-18" style="color: red"></i> Tìm kiếm phổ biến</div>`;

              $.each(json.product_populars, function (key, item) {
                if (item.blank == 1) {
                  html += `<a href="${ item.link }" target="_blank"><h5 class="step_product">${ item.title }</h5></a>`
                } else {
                  html += `<a href="${ item.link }"><h5 class="step_product">${ item.title }</h5></a>`
                }
              });

            html += ` </div>`;

          $('#search_popular').html(html);
        }
      });
    }
  }

  $("#filter_name").autocomplete("getdata.php?lan=" + lang, {
    width: widht_complete,
    resultsClass: "ac_results col-lg-7",
    matchContains: true,
  });

  $("#notification").on("click", function () {
    $("#count_unread").text("");
    $(".notification span").removeClass("visible");

    updateCountNotification();
  });

  $("#show-list-notification").on("click", function () {
    $(".drop-mini-notification").toggle();
  });

  window.addEventListener("click", function (e) {
    if (
      check_login == 1 &&
      !document.getElementById("notification").contains(e.target)
    ) {
      $(".drop-mini-notification").hide();
    }
  });

  $("#dismiss, .overlay").on("click", function () {
    $("#sidebar").removeClass("active");
    $(".overlay").removeClass("active");
    $("body").css("position", "unset");
  });

  $("#sidebarCollapse").on("click", function () {
    $("#sidebar").addClass("active");
    $(".overlay").addClass("active");
    $(".collapse.in").toggleClass("in");
    $("a[aria-expanded=true]").attr("aria-expanded", "false");
    $("body").css("position", "fixed");
  });

   //  Các Sự kiện hover header
  add_hover();

  // Hiển thị thông báo khi mới load trang
  show_notification();

  // Load 10 thông báo đầu tiên khi vào header
  $.ajax({
    url: "index.php?route=common/header/getNotifications",
    dataType: "json",
    type: "get",
    success: function (json) {
      $("#loadNotification").show();
      $("#waite-load-more").hide();

      if (json["notifications"] != "") {
        $.each(json["notifications"], function (key, value) {

          $("#list-notification").append(`
            <a${
              value.action != "OPEN_TRANSACTION_VIEW" ? ' target="_blank"' : ""
            } href="${value.url}">
            <div class="once-notification row${
              value.status > 0 ? " drop-notification-seen" : ""
            }" data-noti-id="${value.notification_id}">
            <div class='icon-letter col-md-1'>
            <i ${
              value.status > 0
                ? 'class="fa fa-2x fa-envelope-open" style="color: gray"'
                : 'class="fa fa-2x fa-envelope" style="color: orangered"'
            }></i>
            </div>
            <div class='col-md-8'>
            <strong>${value.title.replace(/[<>]/g, "")}</strong>
            <p>${value.body.replace(/[<>]/g, "")}</p>
            </div>
            <div class="col-md-3 text-right">${value.date_notify}</div>
            </div>
            </a>
          `);
        });

        if (json["notifications"].length > 9) {
          $("#drop-box-notificaiton").append(
            '<h3 class="btn btn-outline-primary" id="readMoreNoti">' +
              '<a id="loadNotification">Xem thêm thông báo</a>' +
              '<a id="waite-load-more">Đang tải thông báo <i class="fa fa-spinner fa-spin" style="color: #2573b6"></i></a>' +
              "</h3>" +
              '<input type="hidden" value="' +
              json.total_notification_one_page +
              '" id="total_noti_page">' +
              '<input type="hidden" value="' +
              json.page_next +
              '" id="page_next">' +
              '<input type="hidden" value="' +
              json.page_current +
              '" id="page_current">'
          );
        }

        var unread = json.count_unread;

        if (unread > 9) {
          $(".notification span").addClass("visible");
          $("#count_unread").text("9+");
        } else if (unread > 0) {
          $(".notification span").addClass("visible");
          $("#count_unread").text(unread);
        } else {
          $("#count_unread").text("");
        }

        btnLoadNotification();
        updateCountNotification(unread);
        show_notification();
      } else {
        $("#drop-box-notificaiton").append(
          "<h4 style='text-align: center;'>Hiện tại bạn chưa có thông báo nào</h4>"
        );

        $("#readMoreNoti").hide();
      }
    },

    error: function (error, msg) {
      console.log(error);
    },
  });

  if (vnpay_instant_hide_mobile != 1 && mobileCheck()) {
    $('.vnpay-instant-hide-mobile').hide();
  }
});

function show_notification() {
  $(".once-notification").on("mousedown", function () {
    var notification_id = $(this).data("noti-id");
    $(this).addClass("drop-notification-seen");
    $(this)
      .find("i")
      .removeClass("fa-envelope")
      .addClass("fa-envelope-open")
      .css("color", "gray");

    $.ajax({
      url: "index.php?route=common/header/isread",
      dataType: "json",
      type: "post",
      data: {
        notification_id: notification_id,
      },
      error: function (error, msg) {
        console.log("error");
      },
    });
  });
}

function updateCountNotification(unread) {
  if (unread > 0) {
    $.ajax({
      url: "index.php?route=common/header/updateCountNotification",
      dataType: "json",
      type: "post",
      data: {
        status: 1,
      },
    });
  }
}

// function btnLoad
function btnLoadNotification() {
  $("#loadNotification").on("click", function () {
    var total_notification_page = $("#total_noti_page").val();
    var page = $("#page_next").val();
    var page_current = $("#page_current").val();

    $(this).hide();
    $("#waite-load-more").show();

    $.ajax({
      url: "index.php?route=common/header/loadNotification",
      dataType: "json",
      type: "post",
      data: {
        page: page,
        total_notification_page: total_notification_page,
        page_current: page_current,
      },
      success: function (json) {
        $("#loadNotification").show();
        $("#waite-load-more").hide();

        $("#total_noti_page").val(json.total_notification_one_page);
        $("#page_next").val(json.page_next);
        $("#page_current").val(json.page_current);

        if (json["notifications"] != "") {
          $.each(json["notifications"], function (key, value) {
            $("#list-notification").append(`
              <a${
                value.action != "OPEN_TRANSACTION_VIEW"
                  ? ' target="_blank"'
                  : ""
              } href="${value.url}">
              <div class="once-notification row${
                value.status > 0 ? " drop-notification-seen" : ""
              }" data-noti-id="${value.notification_id}">
              <div class='icon-letter col-md-1'>
              <i ${
                value.status > 0
                  ? 'class="fa fa-2x fa-envelope-open" style="color: gray"'
                  : 'class="fa fa-2x fa-envelope" style="color: orangered"'
              }></i>
              </div>
              <div class='col-md-8'>
              <strong>${value.title.replace(/[<>]/g, "")}</strong>
              <p>${value.body.replace(/[<>]/g, "")}</p>
              </div>
              <div class="col-md-3 text-right">${value.date_notify}</div>
              </div>
              </a>
            `);
          });

          show_notification();
        } else {
          $("#readMoreNoti").hide();
        }
      },

      error: function (error, msg) {
        console.log(error);
      },
    });
  });
}

$('.close-alert-add-cart').on('click', function () {
   $('.alert-add-cart').css('display', 'none');
});

// Event khi click vào Mua siêu tốc với Momo
$('#buy-with-momo-instant').click(function () {
  let product_id = $('#momo-product-id-header').val();

  if (product_id) {
    $('#momo-product-id-header').val(product_id);

    $.ajax({
        url: "index.php?route=api/momo_instant/check_momo_instant_option",
        type: 'post',
        dataType: 'json',
        data: {
            product_id : product_id,
        },
        beforeSend: function() {
            $('.screen-modal').show();
        },
        success: function (result) {
            if (result.success == true && result.momo_instant_status == true) {
              if (result.product_option == true) {
                location.href = result.product_url;
              } else {
                $('#momo-payment-modal-header').modal('show');
              }
            } else {
              alert('Không tìm thấy sản phẩm hoặc sản phẩm không thể thanh toán bằng Momo!');
            }
        },
        complete: function() {
            $('.screen-modal').hide();
        }
    });
  } else {
    alert('Không tìm thấy sản phẩm cần thanh toán!');
  }
});

// Click mua ngay vnpay form login
$('#buy-with-vnpay-instant').click(function () {
  let product_id = $('#vnpay-product-id-header').val();

  if (product_id) {
    $('#vnpay-product-id-header').val(product_id);

    $.ajax({
      url: "index.php?route=api/momo_instant/check_momo_instant_option",
      type: 'post',
      dataType: 'json',
      data: {
        product_id : product_id,
      },
      beforeSend: function() {
        $('.screen-modal').show();
      },
      success: function (result) {
        if (result.success == true && result.vnpay_instant_status == true) {
          if (result.product_option == true) {
            location.href = result.product_url;
          } else {
            $('#vnpay-instant-modal-header').modal('show');
          }
        } else {
          alert('Không tìm thấy sản phẩm hoặc sản phẩm không thể thanh toán bằng Momo!');
        }
      },
      complete: function() {
        $('.screen-modal').hide();
      }
    });
  } else {
    alert('Không tìm thấy sản phẩm cần thanh toán!');
  }
});

// Xử lý mua ngay với Momo
let is_mobile = mobileCheck();

$("#momo-instant-btn-header").click(function () {
  let email = $("#momo-email-header").val();
  let product_id = $("#momo-product-id-header").val();

  if (email == "" || product_id == "") {
      alert("Không được để trống địa chỉ Email");
      return;
  }

  $.ajax({
      method: "POST",
      url: "index.php?route=api/momo_instant",
      data: {product_id: product_id, email: email, is_mobile: is_mobile},
      dataType: "json",
  }).done(function(data) {
      if (data.success == true) {
        if (mobileCheck()) {
          // Xử lí với Mobile
          if (typeof data.payUrl == "undefined") {
            alert('Đã có lỗi xảy ra. Vui lòng thử tải lại trang và thực hiện lại!');
          }

          location.href = data.payUrl;
        } else {
          // Xử lí với PC
          show_qrcode_momo(data);
        }
      } else {
          alert(data.error_message);
      }
  });
});

// Xử lí hiện thị mã QR Code Momo
function show_qrcode_momo(data) {
  // Hide login modal and email input modal
  $('#momo-payment-modal-header').modal('hide');
  $('#modal-mini-login').modal('hide');

  // Xử lí Momo QRCode
  $('#momo-payment-modal').modal('hide');

  $('.momo-payment-qrcode img').attr('src', data.qrcode_url);
  $('#momo-price').text(data.price);
  $('#momo-fee').text(data.fee);
  $('#momo-total-price').text(data.total_price);
  countdown_instant('momo');

  $('#qrcode-momo-modal').modal({backdrop: 'static', keyboard: true, show: true});
  check_qrcode_momo_transaction();
}

// Hàm check giao dịch Momo thành công hay thất bại
function check_qrcode_momo_transaction() {
  // 3s một lần check
  let time = 3000;

  setInterval(function(){
    $.ajax({
      method: "POST",
      url: "index.php?route=api/momo_instant/check_qrcode_momo",
      dataType: "json",
    }).done(function(data) {
      if (data.success == true) {
        $('#momo-qrcode-loading').show();
        window.location = data.redirect_url;
      }
    });
  }, time);
}

// Xử lý mua ngay với Vnpay
$("#vnpay-instant-btn-header").click(function () {
  let email = $("#vnpay-email-header").val();
  let product_id = $("#vnpay-product-id-header").val();
  let is_mobile = mobileCheck();

  if (email == "" || product_id == "") {
    alert("Không được để trống địa chỉ Email");
    return;
  }

  $.ajax({
    method: "POST",
    url: "index.php?route=api/vnpay_instant",
    data: {product_id: product_id, email_receiver_game: email, is_mobile: is_mobile},
    dataType: "json",
  }).done(function(data) {
    if (data.success == true) {
      if (data.status_mobile_disable) {
        // Xử lí với Mobile
        alert('chức năng này đăng tắt với mobile');

        location.href = '';
      } else {
        // Xử lí với PC
        show_qrcode_vnpay(data);
      }
    } else {
      alert(data.error_message);
    }
  });
})

// Xử lí hiện thị mã QR Code Vnpay
function show_qrcode_vnpay(data) {
  // Hide login modal and email input modal
  $('#vnpay-instant-modal-header').modal('hide');
  $('#modal-mini-login').modal('hide');

  // Xử lí Vnpay QRCode
  $('#vnpay-instant-modal').modal('hide');

  $('#vnpay-qrcode-modal #content-qr-code img').attr('src', data.qr_code_data);
  $('#vnpay-qrcode-modal #vnpay-amount-origin').html(data.amount_origin);
  $('#vnpay-qrcode-modal #vnpay-fee').html(data.fee);
  $('#vnpay-qrcode-modal #vnpay-amount-total').html(data.amount_total);

  $('#vnpay-qrcode-modal').modal({backdrop: 'static', keyboard: true, show: true});
  countdown_instant('vnpay');
  check_qrcode_vnpay_transaction(data.request_id);
}

// Hàm check giao dịch Vnpay thành công hay thất bại
function check_qrcode_vnpay_transaction(request_id) {
  // 3s một lần check
  let time = 3000;

  setInterval(function(){
    $.ajax({
      method: "POST",
      url: "index.php?route=api/vnpay_instant/response",
      dataType: "json",
      data: {
        request_id: request_id,
        vnpay_instant: true
      }
    }).done(function(json) {
      if (json.success == true) {
        if (json.redirect_url) {

          $('#vnpay-qrcode-loading').show();
          window.location.href = json.redirect_url;
        } else {
          window.location.reload()
        }
      }
    });
  }, time);
}

var downloadTimer;

function countdown_instant(type) {
  var timeleft = 300;

  set_timeleft(type, timeleft);
  clearInterval(downloadTimer);
  
  downloadTimer = setInterval(function(){
    if (timeleft <= 0){
      clearInterval(downloadTimer);
      if (type == 'momo') {
        alert('Mã QR Code thanh toán Momo đã hết hiệu lực!');
      } else {
        alert('Mã QR Code thanh toán Vnpay-QR đã hết hiệu lực!');
      }

      location.reload();
    }

    set_timeleft(type, timeleft);

    timeleft -= 1;
  }, 1000);
}

function set_timeleft(type, timeleft) {
  if (type == 'momo') {
    $("#momo-qrcode-countdown").text(timeleft);
  }

  if (type == 'vnpay') {
    $("#vnpay-qrcode-countdown").text(timeleft);
  }
}
