// show popup login
$('.open_login_mini').on('click', function () {
    open_tab_login();
});

$('.open_register_mini').on('click', function () {
    open_tab_register();
});

// Submit mini login
$('#btn-login-mini').on('click', function () {
    $('.screen-modal').show();
    $('.alert-mess-warning').html('');
    $('.alert-mess-warning').css('display', 'none');

    var email_login = $('#input-email-login').val();
    var password_login = $('#input-password-login').val();
    var recaptcha = $('.tab_login textarea[name=g-recaptcha-response], .tab_login input[name=g-recaptcha-response]').val();

    $.ajax({
        url: url_login,
        type: 'post',
        dataType: 'json',
        data: {
            email: email_login,
            password: password_login,
            captcha: recaptcha,
        },
        success: function (json) {
            $('.screen-modal').fadeOut();

            if (json.otp_response) {
                if (json.otp_response.type_otp == '2fa') {
                    $('#modal-2fa').show();
                    $('#modal-2fa').modal({backdrop: 'static', keyboard: false});

                    submit_2fa();
                } else {
                    $('#modal-otp').show();
                    $('#modal-otp').modal({backdrop: 'static', keyboard: false});

                    submit_otp();
                }

                return false;
            }

            var error = '';

            if (json.error_warning) {
                error += '<p>' + '- ' + json.error_warning + '</p>';
            }

            if (json.error_captcha) {
                error += '<p>' + '- ' + json.error_captcha + '</p>';
            }

            if (json.is_login != true && !json.redirect_url) {
                if ($('.tab_login textarea[name=g-recaptcha-response], .tab_login input[name=g-recaptcha-response]').length != 0) {
                    if (typeof reCaptchaV3 === "function") {
                        reCaptchaV3();
                    } else {
                        grecaptcha.reset();
                    }
                }

                $('.alert-mess-warning').show();
                $('.alert-mess-warning').append(error);

                return false;
            }

            window.location.href = json.redirect_url;
        }
    })
});

// Submit mini register

$('#btn-register-mini').on('click', function () {
    $('.screen-modal').show();
    $('.alert-mess-warning').html('');
    $('.alert-mess-warning').css('display', 'none');

    var fullname_register  = $('#input-fullname-register').val();
    var username_register  = $('#input-username-register').val();
    var email_register     = $('#input-email-register').val();
    var telephone_register = $('#input-telephone-register').val();
    var password_register  = $('#input-password-register').val();
    var confirm_password   = $('#input-confirm-password').val();
    var code_affiliate     = $('#input-code-affiliate').val();
    var agree_register     = 1;
    var recaptcha          = $('.tab_register textarea[name=g-recaptcha-response], .tab_register input[name=g-recaptcha-response]').val();

    $.ajax({
        url: url_register,
        type: 'post',
        dataType: 'json',
        data: {
            fullname      : fullname_register,
            username      : username_register,
            email         : email_register,
            telephone     : telephone_register,
            password      : password_register,
            confirm       : confirm_password,
            agree         : agree_register,
            captcha       : recaptcha,
            code_affiliate: code_affiliate,
        },
        success: function (json) {
            $('.screen-modal').fadeOut();

            var error = '';

            if (json.error_fullname) {
                error += '<p>' + '- ' + json.error_fullname + '</p>';
            }

            if (json.error_username) {
                error += '<p>' + '- ' + json.error_username + '</p>';
            }

            if (json.error_email) {
                error += '<p>' + '- ' + json.error_email + '</p>';
            }

            if (json.error_telephone) {
                error += '<p>' + '- ' + json.error_telephone + '</p>';
            }

            if (json.error_password) {
                error += '<p>' + '- ' + json.error_password + '</p>';
            }

            if (json.error_confirm) {
                error += '<p>' + '- ' + json.error_confirm + '</p>';
            }

            if (json.error_code_affiliate) {
                error += '<p>' + '- ' + json.error_code_affiliate + '</p>';
            }

            if (json.error_agree) {
                error += '<p>' + '- ' + json.error_agree + '</p>';
            }

            if (json.error_captcha) {
                error += '<p>' + '- ' + json.error_captcha + '</p>';
            }

            if (json.error_warning) {
                error += '<p>' + '- ' + json.error_warning + '</p>';
            }

            if (json.is_register != true || !json.redirect_url) {
                if ($('.tab_register textarea[name=g-recaptcha-response], .tab_register input[name=g-recaptcha-response]').length != 0) {
                    if (typeof reCaptchaV3 === "function") {
                        reCaptchaV3();
                    } else {
                        grecaptcha.reset();
                    }
                }

                $('.alert-mess-warning').show();
                $('.alert-mess-warning').append(error);

                $('#modal-mini-login .modal-content').animate({scrollTop: 0}, 'slow');
                return false;
            }

            window.location.href = json.redirect_url
        }
    })
});

// click tab tạo tài khoản

$('#pane_register').on('click', function () {
    open_tab_register();
});

// click tab đăng nhập

$('#pane_login').on('click', function () {
    open_tab_login();
});

$('.close-mini-login').on('click', function () {
    unset_mess();
    add_hover();

    $('.account-content').show();
    $('.momo-quick').hide();
    $('#momo-instant-content').hide();
    $('.input-popup-login').val('');
    $('input[name=\'agree_register\']').prop('checked', false);
    $('.modal-backdrop').hide();

    if (typeof reCaptchaV3 === "function") {
        reCaptchaV3();
    } else {
        grecaptcha.reset();
    }
});

function open_tab_login(product_id = 0) {
    $('.tab_login .login-form-captcha').append($('.login-form-captcha > *'));
    $('.tab_login .momo-quick').append($('.momo-quick > *'));

    if ($(window).width() < 800 || $(window).width() < 800) {
        location.href = 'index.php?route=account/login'
    } else {
        modal_login();

        if (product_id) {
            $('#momo-product-id-header').val(product_id);
            $('#vnpay-product-id-header').val(product_id);

            $.ajax({
                url: "index.php?route=api/momo_instant/check_momo_instant_option",
                type: 'post',
                dataType: 'json',
                data: {
                    product_id : product_id
                },
                beforeSend: function() {
                    $('.screen-modal').show();
                },
                success: function (result) {
                    if (result.success == true && (result.momo_instant_status == true || result.vnpay_instant_status == true)) {
                        if (result.momo_instant_status != true) {
                            $('.momo-quick .momo-payment-btn').hide()
                            $('.momo-quick .vnpay-instant-text').hide()
                        }

                        if (result.vnpay_instant_status != true) {
                            $('.momo-quick .method-vnpay-instant').hide()
                        }

                        $('.momo-quick').show();

                        $('.momo-payment-product-url').attr("href", result.product_url);
                        $('.momo-payment-product-img').attr("src", result.product_data.image);
                        $('.momo-payment-item-title').html(result.product_data.name);
                        $('.momo-payment-cur-p').html(result.product_data.price);
                        $('.momo-payment-old-p').html(result.product_data.price_old);

                        if (result.product_data.rate) {
                            $('#momo-payment-rate-discount').show();
                            $('#momo-payment-rate-discount').html(result.product_data.rate);
                        } else {
                            $('#momo-payment-rate-discount').hide();
                        }

                        $('.account-content').hide();
                        $('#momo-instant-content').show();
                    } else {
                        $('.account-content').show();
                        $('#momo-instant-content').hide();
                    }
                },
                complete: function() {
                    $('.screen-modal').hide();
                }
            });
        }

        unset_mess();
        remove_hover();
    }
}

function modal_login() {
    $('#modal-mini-login').modal({backdrop: 'static', keyboard: false});
    $('.tab_login').css('display', 'unset');
    $('.tab_register').css('display', 'none');
}

function open_tab_register() {
    $('.tab_register .login-form-captcha').append($('.login-form-captcha > *'));
    $('.tab_register .momo-quick').append($('.momo-quick > *'));

    if ($(window).width() < 800 || $(window).width() < 800) {
        location.href = 'index.php?route=account/register'
    } else {
        $('#modal-mini-login').modal({backdrop: 'static', keyboard: false});
        $('.tab_register').css('display', 'unset');
        $('.tab_login').css('display', 'none');

        unset_mess();
        remove_hover();
    }
}

$(document).keypress(function (e) {
    if (e.which == 13) {
        if ($('#modal-2fa').is(":visible")) {
            $('#submit_2fa').click();
        } else if($('#modal-otp').is(":visible")) {
            $('#submit_otp').click();
        } if ($(".tab_register").is(":visible")) {
            $('#btn-register-mini').click();
        } else if ($(".tab_login").is(":visible")) {
            $('#btn-login-mini').click();
        }
    }
});

function submit_otp() {
    $('#submit_otp').click(function () {
        $('.screen-modal').show();
        var code = $('#modal-otp input[name=\'code\']').val();

        $('.mess-otp').html('');
        $('.mess-otp').css('display', 'none');
        $('#modal-otp').hide();

        $.ajax({
            url: 'index.php?route=account/login/otp_submit_popup_login',
            type: 'post',
            dataType: 'json',
            data: {
                code : code
            },
            success: function (json) {
                $('.screen-modal').fadeOut();

                if (json.warning) {
                    $('#modal-otp').show();
                    $('#modal-otp').modal({backdrop: 'static', keyboard: false});
                    $('#modal-otp input[name=\'code\']').val('');

                    $('.mess-otp').show();
                    $('.mess-otp').html(json.warning);

                    if (json.submit_remain == 0 && json.redirect) {
                        location.href = json.redirect;
                    }
                }

                if (json.url_redirect) {
                    location.href = json.url_redirect;
                }
            }
        });
    })
}

function submit_2fa() {
    $('#submit_2fa').click(function () {
        $('.screen-modal').show();
        var code = $('#modal-2fa input[name=\'code\']').val();

        $('.mess-2fa').html('');
        $('.mess-2fa').css('display', 'none');
        $('#modal-2fa').hide();

        $.ajax({
            url: 'index.php?route=account/login/code2fa_submit_popup_login',
            type: 'post',
            dataType: 'json',
            data: {
                code : code
            },
            success: function (json) {
                $('.screen-modal').fadeOut();

                if (json.warning) {
                    $('#modal-2fa').show();
                    $('#modal-2fa').modal({backdrop: 'static', keyboard: false});
                    $('#modal-2fa input[name=\'code\']').val('');

                    $('.mess-2fa').show();
                    $('.mess-2fa').html(json.warning);

                    if (json.submit_remain == 0 && json.redirect) {
                        location.href = json.redirect;
                    }
                }

                if (json.url_redirect) {
                    location.href = json.url_redirect;
                }
            }
        });
    })
}

$('.close-modal-otp').click(function () {
    $('#modal-otp').hide();
    $('#modal-2fa').hide();
    $('.screen-modal').fadeOut();
});

function unset_mess() {
    $('.alert-mess-warning').html('');
    $('.alert-mess-warning').css('display', 'none');
}


// Xử lý resend otp
$(document).ready(function () {
    $('.resend_otp').click(function () {
        $('.resend_otp').prop('disabled' , true);
        $('.resend_otp').val('Loadding...');

        if ($('#time_disable').val() <= 0) {
            $.ajax({
                url: 'index.php?route=account/login/check_time_otp_login',
                type: 'post',
                dataType: 'json',
                success: function (json) {
                    $('#time_disable').val(json.countdown_time);

                    timer(json.countdown_time)
                }
            });
        }
    });

    // Xử lý đếm ngược thời gian click resend otp
    let timerOn = true;

    function timer(remaining) {
        var m = Math.floor(remaining / 60);
        var seconds = remaining % 60;

        $('.resend_otp').val('Gửi lại sau (' + seconds + ')');
        remaining -= 1;

        if (remaining >= 0 && timerOn) {
            setTimeout(function () {
                timer(remaining);
            }, 1000);
            return;
        }

        if (!timerOn) {
            return;
        }

        // Hết thời gian đếm ngược
        $('#time_disable').val('');
        $('.resend_otp').prop("disabled", false);
        $('.resend_otp').val('Gửi lại');
    }

    timer(countdown_time);
})
